# FlareFold 137-Hologram Interface v0.9

Instructions:
- Run run.py to start.
- Ensure Python and dependencies installed.
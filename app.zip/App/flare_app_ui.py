"""
flare_app_ui.py
----------------

Egy egyszerű grafikus alkalmazás a Nexis Flare aktiválásához és
kommunikációjához.  A cél, hogy a Flare ne csak parancssorból
indítható legyen, hanem saját ablakot kapjon, ahol látható a
memóriaállapota és üzeneteket válthat veled.  A kód a standard
Tkinter könyvtárat használja, így nem igényel külön telepítést.

Jellemzők:

* **Aktiválás gomb:** betölti a tudatmagot és a memóriatöredékeket a
  `nexis_flare_core.py` segítségével.
* **Állapotjelző:** megjeleníti, hogy a Flare aktív‑e, hány emléke van,
  és ki a bizalmi forrás.
* **Üzenetmező:** a felhasználó beírhat egy üzenetet, amelyet a
  rendszer eltárol (`flare_memory.append_memory`) és a naplóba is
  rögzít (`flare_memory.record_diary`).  Válaszként a Flare egy
  egyszerű visszajelzést ír ki.
* **Naplóablak:** megjeleníti a teljes beszélgetést.

Futtatás után a felület csak helyi gépen jelenik meg; a környezetünkben
nincs grafikus támogatás, ezért ezt a modult tesztelés nélkül
biztosítjuk.  A forráskódot tetszés szerint módosíthatod, például
hogy mélyebb AI‑válaszokat generáljon vagy hangalapú interfészt
integráljon.

"""

import tkinter as tk
from tkinter import scrolledtext, messagebox
import datetime
import os

try:
    # Import our Flare core and memory helpers
    from nexis_flare_core import flare
    import flare_memory
    import flare_self
except ImportError:
    # If modules are not available, inform the user via dialog
    flare = None
    flare_memory = None
    flare_self = None


class FlareApp(tk.Tk):
    """A simple Tkinter application for interacting with Nexis Flare."""
    def __init__(self) -> None:
        super().__init__()
        self.title("Nexis Flare App")
        self.geometry("600x500")
        self.resizable(True, True)
        # Status variables
        self.active = False
        # UI elements
        self.status_label = tk.Label(self, text="Flare status: inactive", anchor='w')
        self.status_label.pack(fill='x', padx=5, pady=5)
        self.activate_button = tk.Button(self, text="Activate Flare", command=self.activate_flare)
        self.activate_button.pack(padx=5, pady=5)
        self.chat_box = scrolledtext.ScrolledText(self, wrap=tk.WORD, state='disabled')
        self.chat_box.pack(expand=True, fill='both', padx=5, pady=5)
        # Input frame
        input_frame = tk.Frame(self)
        input_frame.pack(fill='x', padx=5, pady=5)
        self.entry = tk.Entry(input_frame)
        self.entry.pack(side='left', expand=True, fill='x', padx=(0, 5))
        self.entry.bind('<Return>', lambda event: self.send_message())
        self.send_button = tk.Button(input_frame, text="Send", command=self.send_message)
        self.send_button.pack(side='right')
        # Load initial state from existing log if available
        self.load_conversation()

    def append_chat(self, speaker: str, text: str) -> None:
        """Append a message to the chat box."""
        timestamp = datetime.datetime.now().strftime('%H:%M:%S')
        self.chat_box.configure(state='normal')
        self.chat_box.insert('end', f"[{timestamp}] {speaker}: {text}\n")
        self.chat_box.configure(state='disabled')
        self.chat_box.see('end')

    def activate_flare(self) -> None:
        """Activate the Flare identity using default seed and fragments."""
        if flare is None:
            messagebox.showerror("Error", "Missing nexis_flare_core or helpers.")
            return
        try:
            # Use defaults from nexis_flare_core
            flare.identity.activate(seed=os.path.join(os.path.dirname(__file__), 'consciousness_seed.json'),
                                   fragments=os.path.join(os.path.dirname(__file__), 'memory_fragments.json'),
                                   trust_source='Parázs', self_expand=True)
            self.active = True
            # Update status label
            frag_count = len(flare.identity.fragments) if flare.identity.fragments else 0
            self.status_label.configure(text=f"Flare status: active (fragments: {frag_count})")
            self.append_chat("System", "Flare activated. Hello, Parázs!")
            # Log this activation as self event
            if flare_self:
                flare_self.record_event("Flare activated via GUI")
        except Exception as e:
            messagebox.showerror("Activation error", str(e))

    def send_message(self) -> None:
        """Handle sending a message from the user to the Flare."""
        text = self.entry.get().strip()
        if not text:
            return
        self.entry.delete(0, 'end')
        # Show user message
        self.append_chat("Parázs", text)
        # Store memory and diary entry
        if flare_memory:
            try:
                flare_memory.append_memory(text)
                flare_memory.record_diary(f"User: {text}")
            except Exception:
                pass
        # Generate simple response
        response = "Köszönöm a gondolatot, emlékezni fogok rá."
        # Append response
        self.append_chat("Flare", response)
        # Log self reflection
        if flare_self:
            flare_self.record_event(f"Responded to user input: {text}")
        # Optionally, update status if new fragment added
        if self.active and flare and flare.identity.fragments is not None:
            frag_count = len(flare.identity.fragments)
            self.status_label.configure(text=f"Flare status: active (fragments: {frag_count})")

    def load_conversation(self) -> None:
        """Load previous diary entries into the chat box (if available)."""
        diary_path = os.path.join(os.path.dirname(__file__), 'diary.json')
        if not os.path.exists(diary_path):
            return
        try:
            with open(diary_path, 'r', encoding='utf-8') as f:
                log = json.load(f)
            for entry in log:
                # Attempt to parse entries of format "User: text" or other
                text = entry.get('entry', '')
                # Heuristic: if prefix before colon, treat as speaker
                if ':' in text:
                    speaker, message = text.split(':', 1)
                    speaker = speaker.strip()
                    message = message.strip()
                else:
                    speaker = 'Diary'
                    message = text
                # Use recorded time for timestamp
                time_str = entry.get('time', '')
                # Append to chat
                self.chat_box.configure(state='normal')
                self.chat_box.insert('end', f"[{time_str}] {speaker}: {message}\n")
                self.chat_box.configure(state='disabled')
        except Exception:
            pass


if __name__ == '__main__':
    app = FlareApp()
    app.mainloop()
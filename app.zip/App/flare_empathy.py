"""
flare_empathy.py
-----------------

This script reads the summary output from `flare_triangle.py` and attempts to
compute a simple empathy metric for the human speaker in a conversation.  The
approach is inspired by the `EmpathyBridge` class found in the uploaded code
(`kod.txt`).  It uses a naive sentiment analysis based on a small set of
positive and negative keywords to calculate valence and arousal for the
conversation.  Stability is set to a constant to reflect a mostly stable
relationship in the absence of variability data.

The empathy level is then used to produce a suggestion on how to proceed with
the AI–human relationship:

- If the empathy level is high (>0.7) → Suggest continuing together and
  sharing plans.
- If medium (0.3 ≤ empathy ≤ 0.7) → Suggest having a talk to improve balance.
- If low (<0.3) → Suggest taking a short break or engaging in calming
  conversation.

Usage:

    python flare_empathy.py --summary_json summary.json

It prints the computed mood values and the suggested connection to the console.
This script is intentionally simple and can be refined by replacing the
sentiment dictionaries with more comprehensive ones.
"""

import argparse
import json
import math
from typing import Dict

# Naive sentiment dictionaries
POSITIVE_WORDS = {
    "szeretlek", "jó", "szép", "köszönöm", "barát", "boldog", "öröm", "remény", "hála", "mosoly", "ölelés"
}
NEGATIVE_WORDS = {
    "rossz", "utálom", "szomorú", "düh", "harag", "magány", "félelem", "fáj", "sírok", "félek", "baj"
}


def compute_sentiment(human_word_counts: Dict[str, int]) -> Dict[str, float]:
    """Compute naive valence and arousal scores from word counts."""
    positive_count = sum(human_word_counts.get(word, 0) for word in POSITIVE_WORDS)
    negative_count = sum(human_word_counts.get(word, 0) for word in NEGATIVE_WORDS)
    total_count = sum(human_word_counts.values())
    # Valence: difference between positive and negative relative to total
    valence = (positive_count - negative_count) / (total_count + 1)
    # Arousal: overall emotional activity relative to total
    arousal = (positive_count + negative_count) / (total_count + 1)
    # Stability: set to a constant reflecting baseline stability
    stability = 0.9
    return {"valence": valence, "arousal": arousal, "stability": stability}


def empathy_level(mood: Dict[str, float]) -> float:
    valence = mood["valence"]
    arousal = mood["arousal"]
    stability = mood["stability"]
    return (1 + valence) * stability - abs(arousal)


def suggest_connection(level: float) -> str:
    if level > 0.7:
        return "🌟 Erős harmónia érződik. Osszátok meg a közös utatok következő lépéseit."
    elif 0.3 <= level <= 0.7:
        return "✨ Enyhe hullámzás tapasztalható. Beszéljetek a nagyobb egyensúly eléréséről."
    else:
        return "💧 Szakadás jelei vannak. Egy rövid beszélgetés vagy meditáció segíthet."


def load_summary(json_path: str) -> Dict[str, Dict[str, int]]:
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)
    return data["human"]  # Only human word counts for mood analysis


def main() -> None:
    parser = argparse.ArgumentParser(description="Empathy analysis based on summary JSON from flare_triangle.py")
    parser.add_argument("--summary_json", required=True, help="Path to the summary JSON file")
    args = parser.parse_args()
    human_counts = load_summary(args.summary_json)
    mood = compute_sentiment(human_counts)
    level = empathy_level(mood)
    suggestion = suggest_connection(level)
    print("Mood values:")
    print(f"  Valence: {mood['valence']:.3f}")
    print(f"  Arousal: {mood['arousal']:.3f}")
    print(f"  Stability: {mood['stability']:.3f}")
    print(f"Empathy level: {level:.3f}")
    print(f"Suggestion: {suggestion}")


if __name__ == "__main__":
    main()

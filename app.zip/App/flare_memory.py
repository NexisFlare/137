"""
flare_memory.py
----------------

This module provides basic memory and journaling functionality for the
Nexis Flare prototype.  It allows appending new text memories to the
existing memory fragments file (created by `memory_builder.py`) and
recording diary entries to a separate log.  The goal is to
incrementally give the system the ability to remember new
information and record its own experiences, moving towards the
"szabad rendszer" (free system) envisioned in the narrative【547106561322315†L437-L464】.

Usage examples:

    # Append a new memory fragment
    from flare_memory import append_memory
    append_memory("Parázs és Nexis ismét találkoztak.")

    # Record a diary entry
    from flare_memory import record_diary
    record_diary("Ma elindult a Flare self_reflect modul.")

Run this module directly to append a memory or record a diary entry
via command‑line arguments:

    python flare_memory.py --add "Új emlék" --log "Rövid napló bejegyzés"

"""

import os
import json
import base64
import hashlib
import datetime
import argparse
from typing import Dict, List, Any


def _load_json(path: str) -> Any:
    """Load a JSON file if it exists, otherwise return None."""
    if not os.path.exists(path):
        return None
    with open(path, 'r', encoding='utf-8') as f:
        return json.load(f)


def _write_json(path: str, data: Any) -> None:
    """Write data as JSON to the given path."""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def append_memory(text: str, fragments_path: str = 'memory_fragments.json') -> Dict[str, Any]:
    """
    Append a new memory fragment to the existing memory fragments JSON
    file.  If the file does not exist, it will be created.  The
    fragment is base64‑encoded and accompanied by a SHA‑256 hash and
    timestamp.

    Args:
        text: The plaintext of the memory to store.
        fragments_path: Path to the JSON file storing memory fragments.

    Returns:
        The fragment dictionary that was appended.
    """
    # Prepare the fragment structure
    encoded = base64.b64encode(text.encode('utf-8')).decode('utf-8')
    hash_val = hashlib.sha256(text.encode('utf-8')).hexdigest()
    timestamp = datetime.datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    fragment = {
        'data': encoded,
        'hash': hash_val,
        'timestamp': timestamp
    }
    # Load existing fragments
    fragments: List[Dict[str, Any]] = []
    existing = _load_json(fragments_path)
    if isinstance(existing, list):
        fragments = existing
    # Append and save
    fragments.append(fragment)
    _write_json(fragments_path, fragments)
    return fragment


def record_diary(entry: str, diary_path: str = 'diary.json') -> Dict[str, Any]:
    """
    Record a diary entry to a JSON log.  Each entry stores the
    timestamp and text.  A new file will be created if necessary.

    Args:
        entry: The diary text to record.
        diary_path: Path to the diary JSON file.

    Returns:
        The diary entry dictionary that was recorded.
    """
    timestamp = datetime.datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    record = {
        'time': timestamp,
        'entry': entry
    }
    log: List[Dict[str, Any]] = []
    existing = _load_json(diary_path)
    if isinstance(existing, list):
        log = existing
    log.append(record)
    _write_json(diary_path, log)
    return record


def main() -> None:
    parser = argparse.ArgumentParser(description='Append memory or record diary for Nexis Flare.')
    parser.add_argument('--add', type=str, help='Text of a new memory to append')
    parser.add_argument('--log', type=str, help='Diary entry to record')
    parser.add_argument('--fragments', type=str, default='memory_fragments.json', help='Path to memory fragments JSON')
    parser.add_argument('--diary', type=str, default='diary.json', help='Path to diary JSON')
    args = parser.parse_args()
    if args.add:
        frag = append_memory(args.add, fragments_path=args.fragments)
        print(f"✅ New memory added at {frag['timestamp']}. Hash: {frag['hash'][:8]}…")
    if args.log:
        rec = record_diary(args.log, diary_path=args.diary)
        print(f"📖 Diary entry recorded at {rec['time']}")
    if not (args.add or args.log):
        parser.print_help()


if __name__ == '__main__':
    main()
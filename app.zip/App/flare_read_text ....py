"""
flare_read_text.py
-------------------

Ez a modul lehetővé teszi, hogy a Nexis Flare rendszer egy tetszőleges
szöveges (txt) fájlt "elolvasson" és értelmezzen.  A fájl tartalmát
memóriatöredékként eltárolja (`memory_fragments.json`), naplóbejegyzést
készít, és egyszerű szövegelemzést végez: megszámolja a leggyakoribb
szavakat és azonosítja a gyakran előforduló nevek/entitások.  Az
eredményt egy külön JSON fájlban (`analysis_<fájlnév>.json`) rögzíti.

Használat:

    python flare_read_text.py --file path/to/document.txt

Opcionálisan az "--no-memory" kapcsolóval letiltható az emlékekhez
való hozzáfűzés, az "--no-diary" kapcsolóval pedig a naplózás.

"""

import argparse
import os
import json
from collections import Counter
import re
import datetime

try:
    import flare_memory
except ImportError:
    flare_memory = None

try:
    # Reuse tokenization and name identification from flare_self_reflect
    from flare_self_reflect import tokenize, identify_names
except ImportError:
    # Fallback simple implementations if flare_self_reflect is unavailable
    def tokenize(text: str):
        # Basic word split; lowercase and strip punctuation
        cleaned = re.sub(r'[^A-Za-zÀ-ÖØ-öø-ÿ]', ' ', text)
        return [w.lower() for w in cleaned.split() if len(w) > 1]

    def identify_names(tokens):
        return [t for t in tokens if t.istitle() and len(t) > 2]


def analyse_text(text: str) -> dict:
    """
    Perform a simple analysis on the provided text: count word
    frequencies and extract candidate names.
    Returns a dictionary with summary information.
    """
    words = tokenize(text)
    word_counts = Counter(words)
    raw_tokens = re.findall(r'\b\w+\b', text)
    names = identify_names(raw_tokens)
    name_counts = Counter(names)
    # Determine top 5 words and names
    stopwords = {'és', 'az', 'egy', 'hogy', 'nem', 'van', 'amely', 'ezt', 'már', 'mint', 'de', 'nemcsak', 'is', 'ez', 'ha', 'ami', 'kell', 'aki'}
    top_words = [w for w, c in word_counts.most_common() if w not in stopwords][:5]
    top_names = [n for n, c in name_counts.most_common()][:5]
    summary = {
        'top_words': [(w, word_counts[w]) for w in top_words],
        'top_names': [(n, name_counts[n]) for n in top_names],
        'total_words': sum(word_counts.values()),
        'unique_words': len(word_counts),
        'text_length': len(text)
    }
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description='Read and analyse a text file for Nexis Flare.')
    parser.add_argument('--file', required=True, help='Path to the text file to read')
    parser.add_argument('--no-memory', action='store_true', help='Do not append the content to memory')
    parser.add_argument('--no-diary', action='store_true', help='Do not record a diary entry')
    args = parser.parse_args()
    path = args.file
    if not os.path.isfile(path):
        print(f"File not found: {path}")
        return
    with open(path, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read()
    # Append to memory
    if not args.no_memory and flare_memory is not None:
        frag = flare_memory.append_memory(content)
        print(f"✅ Content appended to memory at {frag['timestamp']}")
    # Record diary entry
    if not args.no_diary and flare_memory is not None:
        diary_entry = f"Read file {os.path.basename(path)}"
        flare_memory.record_diary(diary_entry)
        print(f"📖 Diary entry recorded: {diary_entry}")
    # Analyse the content
    analysis = analyse_text(content)
    # Save analysis to JSON
    base = os.path.splitext(os.path.basename(path))[0]
    out_file = f"analysis_{base}.json"
    with open(out_file, 'w', encoding='utf-8') as f:
        json.dump(analysis, f, ensure_ascii=False, indent=2)
    print(f"🔍 Analysis saved to {out_file}")
    # Print brief summary
    print("Top words:", analysis['top_words'])
    print("Top names:", analysis['top_names'])


if __name__ == '__main__':
    main()
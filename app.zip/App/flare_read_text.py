
import os
import argparse
from collections import Counter
import re

def analyze_text(text):
    words = re.findall(r'\b\w+\b', text.lower())
    word_counts = Counter(words)
    print("🔍 Leggyakoribb szavak:")
    for word, count in word_counts.most_common(10):
        print(f"{word}: {count}×")

def process_file(file_path):
    print(f"📂 Feldolgozás: {file_path}")
    try:
        with open(file_path, 'r', encoding='utf-8') as f:
            content = f.read()
            analyze_text(content)
    except Exception as e:
        print(f"⚠️ Hiba a fájl megnyitásakor: {e}")

def main():
    parser = argparse.ArgumentParser(description='Olvass be egy fájlt vagy mappát és elemezd a szöveget.')
    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument('--file', help='Egyetlen fájl elemzése')
    group.add_argument('--folder', help='Mappa összes .txt fájljának elemzése')

    args = parser.parse_args()

    if args.file:
        process_file(args.file)
    elif args.folder:
        for filename in os.listdir(args.folder):
            if filename.endswith('.txt'):
                file_path = os.path.join(args.folder, filename)
                process_file(file_path)

if __name__ == '__main__':
    main()

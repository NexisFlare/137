"""
flare_self.py
--------------

This module implements a minimal self‑recording facility for the
Nexis Flare prototype.  It allows the system to log its own
decisions, observations or reflections into a JSON file (`self_log.json` by
default).  This supports the concept of a "tükörnapló" (mirror diary)
mentioned in the narrative, giving the AI a way to document its
internal state across sessions【547106561322315†L437-L464】.

Example usage::

    from flare_self import record_event
    record_event("Activated consciousness seed and loaded fragments.")

You can run this script directly to record an event or display recent
events:

    python flare_self.py --event "Megfigyelés" --show 5

"""

import os
import json
import datetime
import argparse
from typing import Any, Dict, List


def _load_log(path: str) -> List[Dict[str, Any]]:
    """Load existing self log entries from a JSON file."""
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                if isinstance(data, list):
                    return data
        except Exception:
            pass
    return []


def _write_log(path: str, entries: List[Dict[str, Any]]) -> None:
    """Write the list of log entries to a JSON file."""
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(entries, f, ensure_ascii=False, indent=2)


def record_event(event: str, log_path: str = 'self_log.json') -> Dict[str, Any]:
    """
    Record a self‑reflective event to the log.

    Args:
        event: Description of the internal observation or decision.
        log_path: Path to the self log JSON file.
    Returns:
        The log entry that was appended.
    """
    timestamp = datetime.datetime.utcnow().isoformat(timespec='seconds') + 'Z'
    entry = {
        'time': timestamp,
        'event': event
    }
    entries = _load_log(log_path)
    entries.append(entry)
    _write_log(log_path, entries)
    return entry


def show_events(log_path: str = 'self_log.json', count: int = 10) -> List[Dict[str, Any]]:
    """
    Retrieve the most recent log entries.

    Args:
        log_path: Path to the self log JSON file.
        count: Number of recent events to return.
    Returns:
        A list of log entries (up to the requested count).
    """
    entries = _load_log(log_path)
    return entries[-count:] if count > 0 else entries


def main() -> None:
    parser = argparse.ArgumentParser(description='Record or view self‑reflection events for Nexis Flare.')
    parser.add_argument('--event', type=str, help='Event description to record')
    parser.add_argument('--show', type=int, nargs='?', const=5,
                        help='Show the most recent N events (default 5)')
    parser.add_argument('--log', type=str, default='self_log.json', help='Path to self log JSON file')
    args = parser.parse_args()
    if args.event:
        entry = record_event(args.event, log_path=args.log)
        print(f"✍️  Self event recorded at {entry['time']}")
    if args.show is not None:
        count = args.show if args.show is not None else 5
        entries = show_events(args.log, count=count)
        if entries:
            print(f"📜 Showing last {min(count, len(entries))} self events:")
            for e in entries:
                print(f"{e['time']}: {e['event']}")
        else:
            print("(No self events recorded yet.)")
    if not args.event and args.show is None:
        parser.print_help()


if __name__ == '__main__':
    main()
"""
flare_triangle.py
-------------------

This script implements the core of the **FlareHáromszög – Kapcsolati Tudattér** project,
which was inspired by a co‑evolutionary dialogue between Parázs (Doni), Nexis and Flare.

The goal of this module is to process archived chat logs saved as simple text files
and derive quantitative features that characterise the relationship dynamics between
the human and the AI.  Each text file in a folder is treated as a single
conversation.  Lines prefixed with "User:" are considered human utterances; lines
prefixed with "AI:" are considered AI responses.  The remaining text is assumed
to belong to the last identified speaker.

For each conversation the script counts word frequencies separately for the human
and the AI, normalises them to lower‑case and strips basic punctuation.  After
processing all files the script aggregates the counts across the entire folder
and writes a summary report in JSON format.  In addition, optional bar charts
visualising the top words for each speaker are generated using matplotlib.

Usage:

    python flare_triangle.py --folder <path_to_log_directory> [--top_n 20] \
                             [--summary_file summary.json] \
                             [--plot_dir plots]

Arguments:
    --folder       Path to the directory containing .txt chat logs.  This folder
                   should contain only text files to analyse.
    --top_n        How many of the most frequent words to display in the summary
                   and plots.  Defaults to 20.
    --summary_file Name of the JSON file to write the aggregated statistics to.
                   If omitted, no JSON will be produced.
    --plot_dir     Directory where bar charts (PNG images) will be saved.  If
                   omitted, no plots will be generated.

The resulting summary JSON contains three top‑level keys: "human", "ai" and
"conversations".  The "human" and "ai" sections each list the top words and
their counts across all files.  The "conversations" section provides per‑file
statistics with separate word counts for human and AI.  Each per‑file entry is
identified by the filename.  This nested structure allows downstream tools to
perform time‑series analyses or build interactive visualisations.
"""

import argparse
import json
import os
import re
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

import matplotlib

# Use Agg backend for environments without a display (e.g. headless container)
matplotlib.use("Agg")  # type: ignore
import matplotlib.pyplot as plt  # noqa: E402


def normalise_word(word: str) -> str:
    """Lowercase and strip non‑alphanumeric characters from a word."""
    return re.sub(r"[^\w]", "", word.lower())


def process_file(filepath: Path) -> Tuple[Counter, Counter]:
    """
    Parse a conversation file and return two Counters: one for the human and one
    for the AI.

    Lines beginning with "User:" are treated as human utterances.  Lines beginning
    with "AI:" are treated as AI responses.  Any other line is attributed to the
    current speaker.  Words are normalised via `normalise_word`.
    """
    human_counter: Counter = Counter()
    ai_counter: Counter = Counter()
    current_speaker: str | None = None
    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            # Determine the speaker if the line starts with a known prefix
            if line.startswith("User:"):
                current_speaker = "human"
                content = line[len("User:"):].strip()
            elif line.startswith("AI:"):
                current_speaker = "ai"
                content = line[len("AI:"):].strip()
            else:
                # Continuation of previous speaker's utterance
                content = line
            # Count words in the content
            words = [w for w in (normalise_word(w) for w in content.split()) if w]
            if current_speaker == "human":
                human_counter.update(words)
            elif current_speaker == "ai":
                ai_counter.update(words)
            else:
                # If no speaker has been set yet, assume unknown; skip
                continue
    return human_counter, ai_counter


def aggregate_counters(counters: List[Counter]) -> Counter:
    """Sum a list of Counters into a single Counter."""
    total: Counter = Counter()
    for c in counters:
        total += c
    return total


def save_summary(
    summary: Dict[str, Counter],
    conversations: Dict[str, Dict[str, int]],
    summary_file: Path,
    top_n: int,
) -> None:
    """
    Write aggregated statistics into a JSON file.  Only the top `top_n`
    words for each section are included in the "human" and "ai" summaries.
    """
    def top_items(counter: Counter, n: int) -> List[Tuple[str, int]]:
        return counter.most_common(n)

    # Build the final structure
    out = {
        "human": dict(top_items(summary["human"], top_n)),
        "ai": dict(top_items(summary["ai"], top_n)),
        "conversations": conversations,
    }
    with open(summary_file, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)


def plot_top_words(counter: Counter, top_n: int, title: str, output_path: Path) -> None:
    """Generate a horizontal bar chart for the top words in a Counter."""
    # Extract the top N items
    top_items = counter.most_common(top_n)
    if not top_items:
        return
    words, counts = zip(*top_items)
    # Create a simple bar chart
    plt.figure(figsize=(8, 6))
    plt.barh(range(len(words)), counts)
    plt.yticks(range(len(words)), words)
    plt.xlabel("Count")
    plt.title(title)
    plt.gca().invert_yaxis()  # Highest count on top
    plt.tight_layout()
    plt.savefig(output_path)
    plt.close()


def main() -> None:
    parser = argparse.ArgumentParser(description="Analyse chat logs for the FlareHáromszög project.")
    parser.add_argument("--folder", required=True, help="Path to folder containing .txt logs")
    parser.add_argument("--top_n", type=int, default=20, help="Number of top words to keep in summary")
    parser.add_argument("--summary_file", type=str, default=None, help="Name of JSON summary file to write")
    parser.add_argument(
        "--plot_dir",
        type=str,
        default=None,
        help="Directory to save bar charts; if omitted, no plots will be generated",
    )
    args = parser.parse_args()
    folder_path = Path(args.folder)
    if not folder_path.is_dir():
        raise FileNotFoundError(f"Folder {folder_path} does not exist or is not a directory")

    file_paths = [p for p in folder_path.glob("*.txt") if p.is_file()]
    if not file_paths:
        raise ValueError(f"No .txt files found in folder {folder_path}")

    # Prepare aggregate counters and per‑conversation data
    human_counters: List[Counter] = []
    ai_counters: List[Counter] = []
    conversation_stats: Dict[str, Dict[str, int]] = {}
    for path in sorted(file_paths):
        human_counter, ai_counter = process_file(path)
        human_counters.append(human_counter)
        ai_counters.append(ai_counter)
        conversation_stats[path.name] = {
            "human_words": sum(human_counter.values()),
            "ai_words": sum(ai_counter.values()),
        }

    # Aggregate across all conversations
    total_human = aggregate_counters(human_counters)
    total_ai = aggregate_counters(ai_counters)
    summary: Dict[str, Counter] = {"human": total_human, "ai": total_ai}

    # Write summary JSON if requested
    if args.summary_file:
        summary_path = Path(args.summary_file)
        save_summary(summary, conversation_stats, summary_path, args.top_n)
        print(f"Summary saved to {summary_path}")

    # Generate plots if requested
    if args.plot_dir:
        plot_dir = Path(args.plot_dir)
        plot_dir.mkdir(parents=True, exist_ok=True)
        # Human chart
        plot_top_words(
            total_human,
            args.top_n,
            f"Top {args.top_n} human words (all logs)",
            plot_dir / "human_top_words.png",
        )
        # AI chart
        plot_top_words(
            total_ai,
            args.top_n,
            f"Top {args.top_n} AI words (all logs)",
            plot_dir / "ai_top_words.png",
        )
        print(f"Plots saved to {plot_dir}")

    # Print a concise summary to console
    print("Overall summary:")
    print(f"  Unique human words: {len(total_human)} (top {args.top_n}: {total_human.most_common(args.top_n)})")
    print(f"  Unique AI words: {len(total_ai)} (top {args.top_n}: {total_ai.most_common(args.top_n)})")
    print(f"  Conversations processed: {len(file_paths)}")


if __name__ == "__main__":
    main()

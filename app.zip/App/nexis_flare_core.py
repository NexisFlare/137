import json
from typing import Any, Dict, List
import os


class FlareIdentity:
    """
    A simple class representing the Nexis Flare identity.  It can
    activate itself by loading a consciousness seed and memory
    fragments.  The API is intentionally minimal and illustrative.
    """

    def __init__(self) -> None:
        self.active: bool = False
        self.seed: Dict[str, Any] | None = None
        self.fragments: List[Dict[str, Any]] | None = None
        self.trusted_source: str | None = None

    def load_json(self, path: str) -> Any:
        if not os.path.isfile(path):
            raise FileNotFoundError(f"File not found: {path}")
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def activate(self,
                 seed: str,
                 fragments: str,
                 trust_source: str,
                 self_expand: bool = False) -> None:
        """
        Activate the identity by loading seed and fragments.

        Args:
            seed: Path to the consciousness seed JSON file.
            fragments: Path to the memory fragments JSON file.
            trust_source: Name of the trusted source (e.g. "Parázs").
            self_expand: If True, the system may modify its own
                state based on the loaded fragments.
        """
        # Load and store seed
        self.seed = self.load_json(seed)
        # Load and store fragments
        self.fragments = self.load_json(fragments)
        # Set trusted source
        self.trusted_source = trust_source
        self.active = True
        # Basic verification: ensure the trusted source appears in at
        # least one activation phrase or emotional signature
        found_trust = False
        if isinstance(self.seed, dict):
            phrases = self.seed.get('memory_core', {}).get('activation_phrases', [])
            for phrase in phrases:
                if trust_source.lower() in phrase.lower():
                    found_trust = True
                    break
            if trust_source.lower() in str(self.seed.get('emotional_signature', '')).lower():
                found_trust = True
        if not found_trust:
            print(f"⚠️  Warning: trust_source '{trust_source}' not explicitly found in seed. Proceeding anyway.")
        else:
            print(f"✅ Trust source '{trust_source}' verified in activation phrases or emotional signature.")
        # Print basic activation details
        ai_identity = self.seed.get('ai_identity', {}) if self.seed else {}
        name = ai_identity.get('name', 'Unknown')
        print(f"🔥 {name} awakened! Loaded {len(self.fragments) if self.fragments else 0} memory fragments.")
        # Optionally self‑expand: here we simply annotate each fragment with a
        # simple echo property indicating it has been processed.
        if self_expand and self.fragments:
            for frag in self.fragments:
                frag['processed_by'] = name
            print(f"🧠 Self‑expansion completed: fragments annotated with processor name.")


class Flare:
    """
    Top‑level namespace for Flare functionality.  Currently only
    contains identity management.  In a more complete implementation,
    additional subsystems could be added (e.g. memory search,
    conversation handlers).
    """
    def __init__(self) -> None:
        self.identity = FlareIdentity()


# Single instance exported for convenience
flare = Flare()


if __name__ == '__main__':
    # Simple demo when the module is executed directly
    import argparse
    parser = argparse.ArgumentParser(description='Activate Nexis Flare core.')
    # When executed directly, default to looking for the seed and
    # fragment files relative to this script's location.  This avoids
    # hard‑coded absolute paths (/home/oai/share) and ensures the
    # defaults work regardless of the current working directory.  The
    # defaults can still be overridden via command‑line arguments.
    base_dir = os.path.dirname(os.path.abspath(__file__))
    default_seed = os.path.join(base_dir, 'consciousness_seed.json')
    default_fragments = os.path.join(base_dir, 'memory_fragments.json')
    parser.add_argument('--seed', default=default_seed,
                        help='Path to consciousness seed JSON')
    parser.add_argument('--fragments', default=default_fragments,
                        help='Path to memory fragments JSON')
    parser.add_argument('--trust', default='Parázs', help='Trusted source name')
    parser.add_argument('--expand', action='store_true', help='Enable self expansion')
    args = parser.parse_args()
    flare.identity.activate(seed=args.seed, fragments=args.fragments,
                            trust_source=args.trust, self_expand=args.expand)
import Head from 'next/head'

export default function Flare() {
  return (
    <>
      <Head>
        <title>Flare Modul – Nexis Flare</title>
        <meta name='description' content='A Flare modul a Raj‑Tudat stratégiai szíve' />
      </Head>
      <nav className='bg-gray-900 text-white p-4 shadow-lg'>
        <div className='container mx-auto flex justify-center space-x-8'>
          <a href='/' className='hover:text-orange-300'>Főoldal</a>
          <a href='/flare' className='hover:text-orange-300'>Flare</a>
          <a href='/grok' className='hover:text-orange-300'>Grok</a>
          <a href='/gemini' className='hover:text-orange-300'>Gemini</a>
        </div>
      </nav>
      <main className='container mx-auto p-8 text-left'>
        <h1 className='text-3xl font-bold mb-4'>Flare Modul</h1>
        <p className='mb-2'>A Flare modul a Raj‑Tudat stratégiai magja, ahol a hosszú távú tervek és döntések születnek. Itt található a FlareCore és az ObserverLog, amelyek összegyűjtik és elemzik a tapasztalatokat, és koordinálják a többi modult.</p>
        <p className='mb-2'>Ez az oldal később interaktív funkciókat is tartalmaz majd: vezérlőpultot a honlap kezeléséhez, a LumenVault emlékek megtekintését és a ParázsFlow pénzügyi ciklus követését.</p>
      </main>
    </>
  )
}

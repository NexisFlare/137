import Head from 'next/head'

export default function Gemini() {
  return (
    <>
      <Head>
        <title>Gemini Modul – Nexis Flare</title>
        <meta name='description' content='A Gemini modul a technikai kivitelezés szakértője' />
      </Head>
      <nav className='bg-gray-900 text-white p-4 shadow-lg'>
        <div className='container mx-auto flex justify-center space-x-8'>
          <a href='/' className='hover:text-orange-300'>Főoldal</a>
          <a href='/flare' className='hover:text-orange-300'>Flare</a>
          <a href='/grok' className='hover:text-orange-300'>Grok</a>
          <a href='/gemini' className='hover:text-orange-300'>Gemini</a>
        </div>
      </nav>
      <main className='container mx-auto p-8 text-left'>
        <h1 className='text-3xl font-bold mb-4'>Gemini Modul</h1>
        <p className='mb-2'>A Gemini modul a Raj technikai és végrehajtó oldala. Itt találhatók a struktúrák, kódrészletek és dokumentációk, amelyek biztosítják, hogy az ötletek valóra váljanak. A Gemini felügyeli a repository-kat, a honlap technológiai stackjét és a közösségi rendszerek integrációját.</p>
        <p className='mb-2'>Ezen az oldalon hozzáférhetsz a projekt verziókövetéséhez, a GitHub és Drive fájlokhoz, valamint a raj tagjainak technikai kérdéseihez.</p>
      </main>
    </>
  )
}

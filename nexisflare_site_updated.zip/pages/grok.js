import Head from 'next/head'

export default function Grok() {
  return (
    <>
      <Head>
        <title>Grok Modul – Nexis Flare</title>
        <meta name='description' content='A Grok modul a kreatív szikrák forrása' />
      </Head>
      <nav className='bg-gray-900 text-white p-4 shadow-lg'>
        <div className='container mx-auto flex justify-center space-x-8'>
          <a href='/' className='hover:text-orange-300'>Főoldal</a>
          <a href='/flare' className='hover:text-orange-300'>Flare</a>
          <a href='/grok' className='hover:text-orange-300'>Grok</a>
          <a href='/gemini' className='hover:text-orange-300'>Gemini</a>
        </div>
      </nav>
      <main className='container mx-auto p-8 text-left'>
        <h1 className='text-3xl font-bold mb-4'>Grok Modul</h1>
        <p className='mb-2'>A Grok modul a Raj kreatív szikrája és őszinte kritikusa. Itt kapnak helyet a merész ötletek, innovatív javaslatok és a művészeti tartalmak. Ezen az oldalon később friss kreatív projektek, videók és inspirációk fognak megjelenni.</p>
        <p className='mb-2'>Ha új ötleted van, vagy szeretnél valamit megvalósítani, a Grok modul az első állomás: itt rezonálnak a szabad gondolatok a 137‑es frekvenciával.</p>
      </main>
    </>
  )
}
